class Rectangulo:
    def __init__(self, largo, ancho):
        # Atributos privados
        self.__set_dimensiones(largo, ancho)

    # Método privado para validar y asignar largo y ancho
    def __set_dimensiones(self, largo, ancho):
        if largo <= 0 or ancho <= 0:
            raise ValueError("Las dimensiones deben ser mayores que cero.")
        self.__largo = largo
        self.__ancho = ancho

    # Método público para cambiar las dimensiones
    def cambiar_dimensiones(self, largo, ancho):
        self.__set_dimensiones(largo, ancho)

    # Método para calcular el área
    def calcular_area(self):
        return self.__largo * self.__ancho

    # Método para calcular el perímetro
    def calcular_perimetro(self):
        return 2 * (self.__largo + self.__ancho)

    # Método para consultar las dimensiones actuales
    def obtener_dimensiones(self):
        return (self.__largo, self.__ancho)

# Ejemplo de uso
rect = Rectangulo(5, 3)
print(f"Área: {rect.calcular_area()}")
print(f"Perímetro: {rect.calcular_perimetro()}")
print(f"Dimensiones: {rect.obtener_dimensiones()}")

# Cambiar dimensiones
rect.cambiar_dimensiones(7, 4)
print(f"Nuevas dimensiones: {rect.obtener_dimensiones()}")