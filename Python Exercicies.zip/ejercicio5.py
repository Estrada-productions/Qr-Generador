class Libro:
    def __init__(self, titulo, autor, num_paginas):
        # Atributos privados
        self.__titulo = titulo
        self.__autor = autor
        self.__num_paginas = num_paginas
        self.__pagina_actual = 1  # El libro comienza en la página 1

    # Método para avanzar un número de páginas
    def avanzar_paginas(self, paginas):
        if self.__pagina_actual + paginas > self.__num_paginas:
            raise ValueError(f"No puedes avanzar más allá de la página {self.__num_paginas}.")
        self.__pagina_actual += paginas

    # Método para retroceder un número de páginas
    def retroceder_paginas(self, paginas):
        if self.__pagina_actual - paginas < 1:
            raise ValueError("No puedes retroceder más allá de la página 1.")
        self.__pagina_actual -= paginas

    # Método para consultar la página actual
    def obtener_pagina_actual(self):
        return self.__pagina_actual

    # Método para obtener la información completa del libro
    def obtener_informacion(self):
        return (f"Título: {self.__titulo}\n"
                f"Autor: {self.__autor}\n"
                f"Número de páginas: {self.__num_paginas}\n"
                f"Página actual: {self.__pagina_actual}")

# Ejemplo de uso
libro = Libro("El Quijote", "Miguel de Cervantes", 500)
print(libro.obtener_informacion())

# Avanzar 50 páginas
libro.avanzar_paginas(50)
print(f"Página actual después de avanzar: {libro.obtener_pagina_actual()}")

# Retroceder 20 páginas
libro.retroceder_paginas(20)
print(f"Página actual después de retroceder: {libro.obtener_pagina_actual()}")

# Intentar avanzar más allá del límite
try:
    libro.avanzar_paginas(460)
except ValueError as e:
    print(e)