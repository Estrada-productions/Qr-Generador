class Estudiante:
    def __init__(self, nombre, edad):
        self.__nombre = nombre
        self.__edad = edad
        self.__notas = []

    def __validar_nota(self, nota):
        if nota < 0 or nota > 100:
            raise ValueError("La nota debe estar entre 0 y 100")
        return nota

    def agregar_nota(self, nota):
        self.__notas.append(self.__validar_nota(nota))

    def calcular_promedio(self):
        if not self.__notas:
            return 0
        return sum(self.__notas) / len(self.__notas)

    def obtener_nombre(self):
        return self.__nombre

    def obtener_edad(self):
        return self.__edad
estudiante = Estudiante("Juan", 20)
estudiante.agregar_nota(80)
estudiante.agregar_nota(90)
print(estudiante.calcular_promedio())  # Imprime 85.0
print(estudiante.obtener_nombre())  # Imprime "Juan"
print(estudiante.obtener_edad())